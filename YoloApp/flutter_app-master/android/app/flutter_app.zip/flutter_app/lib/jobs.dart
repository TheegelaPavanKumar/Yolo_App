class Job {
  final String title;
  Job(this.title);
}