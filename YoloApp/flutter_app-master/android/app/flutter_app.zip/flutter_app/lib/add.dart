import 'package:flutter/material.dart';

class AddPage extends StatelessWidget {
  @override
  Widget build(BuildContext context){
    return Container(
        child: Center(
            child: Text('Adding Jobs Page')
        )
    );
  }
}